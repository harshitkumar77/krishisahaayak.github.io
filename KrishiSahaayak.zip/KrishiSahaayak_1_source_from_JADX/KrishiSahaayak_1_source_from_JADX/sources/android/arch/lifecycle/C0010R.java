package android.arch.lifecycle;

/* renamed from: android.arch.lifecycle.R */
public final class C0010R {
}
